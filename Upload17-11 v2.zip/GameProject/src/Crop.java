public class Crop {
    String cropName = "default";

    int cost = 0;
    int dayCountdown = 0;
    int foodPayout = 0;
    int season = 0; //1 Summer, 2 Autumn, 3 Winter, 4 Spring
}
