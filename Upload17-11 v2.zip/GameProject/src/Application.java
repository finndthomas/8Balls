import nl.saxion.app.SaxionApp;

import java.awt.*;
import java.util.ArrayList;

public class Application implements Runnable {

    public static void main(String[] args) {
        SaxionApp.start(new Application(), 1200, 600);
    }

    int dayCount = 1;//Season change every 30 days
    int season = 1;//1 Summer, 2 Autumn, 3 Winter, 4 Spring
    Tile[] tiles;
    Crop[] crops;

    public void run() {
        SaxionApp.setFill(Color.black);
        SaxionApp.setBackgroundColor(Color.white);
        drawBoard();
        crops = cropSetup();
        tiles = tileSetup();
        ///////TEST FOR PICTURE LOADING//////
        Tile tileTemp = tiles[0];
        tileTemp.tilePosition[0] = 400;
        tileTemp.tilePosition[1] = 132;
        SaxionApp.drawImage(tileTemp.tilePicture,
                (tileTemp.tilePosition[0])-1,(tileTemp.tilePosition[1])+1,129,65);
        /////////////////////////////////////

    }
    public void drawBoard () {
        //starting pos x+400 and y+100
        SaxionApp.setBorderSize(2);
        SaxionApp.setBorderColor(Color.black);

        int[] position = {400,100}; // 0 = X, 1 = Y
        int[] increments = {64,32}; // 0 = X, 1 = Y

        SaxionApp.drawLine(position[0],position[1], position[0]+(increments[0]*5), position[1]+(increments[1]*5)); //top line going right
        SaxionApp.drawLine(position[0]-(increments[0]),position[1]+(increments[1]),position[0]+(increments[0]*4), position[1]+(increments[1]*6)); //first divider line, forward slash
        SaxionApp.drawLine(position[0]-(increments[0]*2),position[1]+(increments[1]*2), position[0]+(increments[0]*3), position[1]+(increments[1]*7)); //second divider line, forward slash
        SaxionApp.drawLine(position[0]-(increments[0]*3),position[1]+(increments[1]*3), position[0]+(increments[0]*2), position[1]+(increments[1]*8)); //third divider line, forward slash
        SaxionApp.drawLine(position[0]-(increments[0]*4),position[1]+(increments[1]*4), position[0]+(increments[0]), position[1]+(increments[1]*9)); //fourth divider line, forward slash

        SaxionApp.drawLine(position[0],position[1], position[0]-(increments[0]*5), position[1]+(increments[1]*5)); //top line going left
        SaxionApp.drawLine(position[0]+(increments[0]),position[1]+(increments[1]), position[0]-(increments[0]*4), position[1]+(increments[1]*6)); //first divider line, back slash
        SaxionApp.drawLine(position[0]+(increments[0]*2),position[1]+(increments[1]*2), position[0]-(increments[0]*3), position[1]+(increments[1]*7)); //second divider line, back slash
        SaxionApp.drawLine(position[0]+(increments[0]*3),position[1]+(increments[1]*3), position[0]-(increments[0]*2), position[1]+(increments[1]*8)); //third divider line, back slash
        SaxionApp.drawLine(position[0]+(increments[0]*4),position[1]+(increments[1]*4), position[0]-(increments[0]), position[1]+(increments[1]*9)); //fourth divider line, back slash

        SaxionApp.drawLine(position[0]-(increments[0]*5),position[1]+(increments[1]*5), position[0], position[1]+(increments[1]*10)); //bottom left line going down
        SaxionApp.drawLine(position[0],position[1]+(increments[1]*10), position[0]+(increments[0]*5), position[1]+(increments[1]*5));//bottom right line going down
    }
    public Tile[] tileSetup(){
        Tile[] tiles = new Tile[25];
        String letters[] = {"A","B","C","D","E"};
        int counter = 0;
        for (int i = 1; i < 6; i++) {
            for (int j = 0; j < 5; j++) {
                Tile tile = new Tile();
                tile.tileID = i+letters[j];

                tiles[counter]=tile;
                counter++;
            }
        }
        return tiles;
    }
    public Crop[] cropSetup(){
        Crop[] crops = new Crop[8];
        String cropNames[] = {"Tomato","Corn", "default", "default", "default", "default", "default", "default",};
        int cropCosts[] = {14,10,0,0,0,0,0,0};
        int cropGrowDays[] = {1,1,0,0,0,0,0,0};
        int cropPayout[] = {21,15,0,0,0,0,0,0};
        int cropSeason[] = {1,4,0,0,0,0,0,0};//1 Summer, 2 Autumn, 3 Winter, 4 Spring
        for (int i = 0; i < 8; i++) {
            Crop crop = new Crop();
            crop.cropName = cropNames[i];
            crop.cost = cropCosts[i];
            crop.dayCountdown = cropGrowDays[i];
            crop.foodPayout = cropPayout[i];
            crop.season = cropSeason[i];
            crops[i] = crop;
        }
        return crops;
    }
}