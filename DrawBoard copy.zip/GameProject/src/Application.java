import nl.saxion.app.SaxionApp;

import java.awt.*;
import java.util.ArrayList;

public class Application implements Runnable {

    public static void main(String[] args) {
        SaxionApp.start(new Application(), 1200, 600);
    }

    public void run() {
        drawBoard();
    }
    public void drawBoard () {
        //starting pos x+400 and y+100
        SaxionApp.drawLine(400,100, 720, 260); //top line going right
        SaxionApp.drawLine(336,132, 656, 292); //first divider line, forward slash
        SaxionApp.drawLine(272,164, 592, 324); //second divider line, forward slash
        SaxionApp.drawLine(208,196, 528, 356); //third divider line, forward slash
        SaxionApp.drawLine(144,228, 464, 388); //fourth divider line, forward slash

        SaxionApp.drawLine(400,100, 80, 260); //top line going left
        SaxionApp.drawLine(464,132, 144, 292); //first divider line, back slash
        SaxionApp.drawLine(528,164, 208, 324); //second divider line, back slash
        SaxionApp.drawLine(592,196, 272, 356); //third divider line, back slash
        SaxionApp.drawLine(656,228, 336, 388); //fourth divider line, back slash

        SaxionApp.drawLine(80,260, 400, 420); //bottom left line going down
        SaxionApp.drawLine(400,420, 720, 260);//bottom right line going down
    }
}